<template>
  <div class="shopcart" >
      <div class="content">
          <div class="content-left">
              <div class="logo-wrapper">
                    <div class="logo">
                        <span class="icon-shopping_cart"></span>
                    </div>
              </div>
              <div class="price">0元</div>
              <div class="desc"></div>
          </div>
          <div class="content-right"></div>
      </div>
  </div>
</template>

<script type="text/ec,ascript-6">
    export default {
        created() {
            console.log(this.seller);
        }
    };
</script>

<style lang="stylus" rel="stylesheet/sylus">
    .shopcart
        position fixed
        bottom 0
        left 0
        z-index 50
        background #000000
        width 100%
        height 48px
        .content
            display flex
            background #141d27
            font-size 0
            .content-left
                flex 1
                .logo-wrapper
                    display inline-block
                    position relative
                    top -10px
                    margin 0 12px
                    padding 6px
                .price
                    display inline-block
                    vertical-align top
                    margin-top 12px
                    line-height 24px
                    padding-right 12px
                    box-sizing border-box
                    border-right 1px solid rgba(255, 255, 255, 0.1)
                    font-size 16px
                    color rgba(255, 255, 255, 0.4)
                .desc
                    display inline-block
                    vertical-align top
                    line-height 24px
                    margin 12px 0 0 12px
            .content-right
                flex 0 0 105px
                width 105px
</style>
