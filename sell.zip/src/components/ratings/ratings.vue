<template>
  <div>I am ratings</div>
</template>

<script type="text/ec,ascript-6">
</script>

<style lang="stylus" rel="stylesheet/sylus">
</style>
